# README

## Project Name
MagDrop4

## Part Name
Base Plate

## Class
Project for EECS 149/249

## Units in .dxf file
**Millimeters (mm)**

## Material
1/4-inch thick plywood  

# Outer Dimensions
500mm x 220mm 

# Notes:
- All holes are d=5mm except for only 4 holes in the middle with d=2.6mm
- Outer contours doesnt have to be really precise, but the holes relative to each other have to.
